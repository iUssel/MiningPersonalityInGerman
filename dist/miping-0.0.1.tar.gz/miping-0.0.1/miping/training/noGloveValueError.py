class NoGloveValueError(Exception):
    """
    TODO docstring Class NoGloveValueError
    """
    pass
