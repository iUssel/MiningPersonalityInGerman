class UserNameError(Exception):
    """TODO PredictionErrorfor proper catch clause"""
    pass


class NotASuitableUserError(Exception):
    """TODO NotSuitableUser"""
    pass
